from google.cloud import storage
import os
import cv2
def hello_world(request):
    """Responds to any HTTP request.
    Args:
        request (flask.Request): HTTP request object.
    Returns:
        The response text or any set of values that can be turned into a
        Response object using
        `make_response <http://flask.pocoo.org/docs/1.0/api/#flask.Flask.make_response>`.
    """
    request_json = request.get_json()
    if (request.args and 'img1' in request.args and 'img2' in request.args and 'img3' in request.args and 'img4' in request.args and 'img5' in request.args and 'img6' in request.args  
        and 'img7' in request.args and 'img8' in request.args and 'img9' in request.args and 'img10' in request.args and 'name' in request.args and 'email' in request.args):
    #if (request.args and 'img1' and 'name' in request.args and 'email' in request.args):
        name = request.args.get('name')
        email = request.args.get('email')
        folder = name + "_" + email
        fileName1 = request.args.get('img1')
        fileName2 = request.args.get('img2')
        fileName3 = request.args.get('img3')
        fileName4 = request.args.get('img4')
        fileName5 = request.args.get('img5')
        fileName6 = request.args.get('img6')
        fileName7 = request.args.get('img7')
        fileName8 = request.args.get('img8')
        fileName9 = request.args.get('img9')
        fileName10 = request.args.get('img10')
        lstOfFiles = [fileName1,fileName2,fileName3,fileName4,fileName5,fileName6,fileName7,fileName8,fileName9,fileName10]
        face_cascade = cv2.CascadeClassifier("haarcascade_frontalface_alt2.xml")
        #lstOfFiles = [fileName1]
        #-------------
        # DOWNLOADS THE FILES FROM GCP FUNCTION
        #os.chdir("/Users/kunal/Documents/AAPersonalAIPROJECT/LOGINLY/Code") # Comment later
        storage_client = storage.Client.from_service_account_json("key.json") #"key.json"
        bucket_name = 'loginly_storage'
        bucket = storage_client.bucket(bucket_name)
        ctFileName = 1
        for i in lstOfFiles:
            blob = bucket.get_blob("Storage/"+folder+"/" + i)
            blob.download_to_filename("/tmp/Img_org_" + str(ctFileName) + ".jpg")
            ctFileName+=1
        #--------------
        # FILE NAMES 
        downloadedFilesName = []
        for i in range(len(lstOfFiles)):
            downloadedFilesName.append("/tmp/Img_org_" + str(i+1) + ".jpg")
        #-------------

        #ffffffffffffffffff

        # CONVERT TO GRAYSCALE IMAGES WITH SCALED ON IMAGE 
        os.mkdir("/tmp/"+folder + "_CLEAN")
        ctFileNameNew = 1
        newFilesName = []
        for i in downloadedFilesName:
            img = cv2.imread(i)
            #ts = img.tobytes()[0:100]
            #return ts
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, 1.1, 4)
            #1.1: scale factor, it specifies how much the image size is reduced with each scale. It improves detection.
            #4: MinNeighbours, specifies how many neighbors each candidate rectangle should have to retain.
            if len(faces) > 0:
                x,y,w,h = faces[0]
            else:
                x,y = 0,0
                w,h = img.shape[0:2]
            crop_img = img[y:y+h, x:x+w]
            currentDir = "/tmp/"
            os.chdir("/tmp/" + folder + "_CLEAN")
            cv2.imwrite("Img_NEW_" + str(ctFileNameNew) + ".jpg", crop_img)
            os.chdir(currentDir)
            newFilesName.append("Img_NEW_" + str(ctFileNameNew) + ".jpg")
            ctFileNameNew+=1
        #-------------- 
        #upload new files
        os.chdir("/tmp/" + folder + "_CLEAN")
        for i in newFilesName:
            blob = bucket.blob("CleanData/" +folder+"/"+ i)
            blob.upload_from_filename(i)
        stringReturn = "" 
        for i in newFilesName:
            stringReturn+=i+";"
        return "Uploaded: " + stringReturn + "\n" + "Name: " + name + "\nEmail:" + email
        
    elif request_json and 'message' in request_json:
        return request_json['message']
    else:
        return f'ERROR'
"""
# This is the function to take in the 10 image names and the user's email and user's 
# name and crops the image and upload to proper folder in GCP 
#-----
# INPUT:   IMG1, IMG2, IMG3 ... IMG10, NAME, EMAIL
#--------------
key = "../GCPKEY/loginly.json"
harascade = '../Models/haarcascades/haarcascade_frontalface_alt2.xml'
# key.json                              file on function      
# haarcascade_frontalface_alt2.xml      file on function 
#--------------
# INPUT NEEDS FOR THE FUNCTION TO CLEAN THE DATA
#fileName0 = 
name = "robert"
email = "robertDowney202@gmail.com"
folder = name + "_" + email
fileName1 = "download (2).jpg"
fileName2 = "download (3).jpg"
fileName3 = "download (4).jpg"
fileName4 = "download (5).jpg"
fileName5 = "download (6).jpg"
fileName6 = "download.jpg"
fileName7 = "images (1).jpg"
fileName8 = "images (2).jpg"
fileName9 = "images.jpg"
lstOfFiles = [fileName1,fileName2,fileName3,fileName4,fileName5,fileName6,fileName7,fileName8,fileName9]
#-------------
# DOWNLOADS THE FILES FROM GCP FUNCTION
os.chdir("/Users/kunal/Documents/AAPersonalAIPROJECT/LOGINLY/Code") # Comment later
storage_client = storage.Client.from_service_account_json(key) #"key.json"
bucket_name = 'loginly_storage'
bucket = storage_client.bucket(bucket_name)
ctFileName = 1
for i in lstOfFiles:
    blob = bucket.blob("Storage/"+folder+"/" + i)
    blob.download_to_filename("Img_org_" + str(ctFileName) + ".jpg")
    ctFileName+=1
#--------------
# FILE NAMES 
downloadedFilesName = []
for i in range(len(lstOfFiles)):
    downloadedFilesName.append("Img_org_" + str(i+1) + ".jpg")
#-------------
# CONVERT TO GRAYSCALE IMAGES WITH SCALED ON IMAGE 
os.mkdir(folder + "_CLEAN")
ctFileNameNew = 1
newFilesName = []
for i in downloadedFilesName:
    img = cv2.imread(i)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    face_cascade = cv2.CascadeClassifier(harascade)
    faces = face_cascade.detectMultiScale(gray, 1.1, 4)
    #1.1: scale factor, it specifies how much the image size is reduced with each scale. It improves detection.
    #4: MinNeighbours, specifies how many neighbors each candidate rectangle should have to retain.
    if len(faces) > 0:
        x,y,w,h = faces[0]
    else:
        x,y = 0,0
        w,h = img.shape[0:2]
    crop_img = img[y:y+h, x:x+w]
    currentDir = os.getcwd()
    os.chdir(folder + "_CLEAN")
    cv2.imwrite("Img_NEW_" + str(ctFileNameNew) + ".jpg", crop_img)
    os.chdir(currentDir)
    newFilesName.append("Img_NEW_" + str(ctFileNameNew) + ".jpg")
    ctFileNameNew+=1
#-------------- 
#upload new files
os.chdir(folder + "_CLEAN")
for i in newFilesName:
    blob = bucket.blob("CleanData/" +folder+"/"+ i)
    blob.upload_from_filename(i)
"""