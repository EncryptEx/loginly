def hello_world(request):
    """Responds to any HTTP request.
    Args:
        request (flask.Request): HTTP request object.
    Returns:
        The response text or any set of values that can be turned into a
        Response object using
        `make_response <http://flask.pocoo.org/docs/1.0/api/#flask.Flask.make_response>`.
    """
    import cv2
    from google.cloud import storage
    import os
    import numpy as np
    request_json = request.get_json()
    if request.args and 'train' in request.args:
        if request.args.get('train') == "RUN":
            storage_client = storage.Client.from_service_account_json("key.json") #"key.json"
            bucket_name = 'loginly_storage'
            bucket = storage_client.bucket(bucket_name)
            blobs = storage_client.list_blobs(bucket_name)
            #--------------------------------------------------
            mainDir = os.getcwd()
            #os.remove("/tmp")
            os.makedirs("/tmp/dataset")
            os.chdir("/tmp/dataset")
            #---------------------------
            #foldersCreated = []
            #for blob in blobs:
            #    if blob.name.startswith("CleanData/") and not blob.name == "CleanData/":
            #        folderNameTemp = blob.name[10:blob.name[10:].find("/")+10]
            #        if not folderNameTemp in foldersCreated:
            #            os.mkdir(folderNameTemp)
            #            foldersCreated.append(folderNameTemp)
            #---------------------------
            titleNames = []
            for blob in blobs:
                if blob.name.startswith("CleanData/") and not blob.name == "CleanData/":
                    #os.chdir(blob.name[10:blob.name[10:].find("/")+10])
                    blob.download_to_filename(blob.name[10:].replace("/", "-*-"))
                    #print(blob.name[10:])
                    #os.chdir("/tmp/dataset")
                    titleNames.append(blob.name[10:blob.name[10:].find("/")+10])
            dataset = "/tmp/dataset/"
            
            titleNamesNew = list(set(titleNames))
            stringReturnTest = ""
            for i in titleNamesNew:
                stringReturnTest+=i + "; "
            #return stringReturnTest #TEST HERE FOR 

            
            titlesNumInt = []
            for i in range(len(titleNamesNew)):
                titlesNumInt.append([titleNamesNew[i] , i+1])
            
            os.chdir(mainDir)
            dirs = os.listdir(dataset)
            faces = []
            labels = []
            labelsInt = []
            ct=1
            for dir_name in dirs:
                if dir_name.startswith("."):
                    continue
                label = dir_name[:dir_name.find("-*-")]
                """label = dir_name
                for image_name in os.listdir(dir_name):
                    if image_name.startswith("."):
                        continue;"""
                image_path = "/tmp/dataset/" + dir_name
                image = cv2.imread(image_path)
                face, rect = detect_face(image)
                if face is not None:
                    faces.append(face)
                    labels.append(label)
                    for i in titlesNumInt:
                        if i[0] == label:
                            labelsInt.append(i[1])
                ct+=1
            
            face_recognizer = cv2.face.LBPHFaceRecognizer_create() 
            face_recognizer.train(faces, np.array(labels))

            face_recognizer.write("MODEL.yml")

            bucket_name = 'loginly_storage'
            bucket = storage_client.bucket(bucket_name)
            blob = bucket.blob("LiveModel/MODEL.yml")
            blob.upload_from_filename("MODEL.yml")
            return "COMPLETED"
            
        else:
            return "TOLD NOT TO RUN"



    elif request_json and 'message' in request_json:
        return request_json['message']
    else:
        return f'Hello World!'


#function to detect face using OpenCV
def detect_face(img):
    import cv2
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    face_cascade = cv2.CascadeClassifier('lbpcascade_frontalface.xml')
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.2, minNeighbors=5);
    if (len(faces) == 0):
        return None, None
    (x, y, w, h) = faces[0]
    return gray[y:y+w, x:x+h], faces[0]